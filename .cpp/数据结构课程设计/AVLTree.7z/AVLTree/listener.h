//
// Created by cht on 2019/5/16.
//
#pragma once
#include<iostream>
using namespace std;

class IOnPageChangedListener
{
public:
    virtual void onPageChanged(string page)
    {

    }
};