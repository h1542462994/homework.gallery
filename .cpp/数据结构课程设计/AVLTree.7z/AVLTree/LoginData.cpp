//
// Created by cht on 2019/12/7.
//
#include "LoginData.h"

string toSimple(LoginData data) {
    return data.username;
}
